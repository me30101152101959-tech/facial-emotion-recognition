"""
fusion.py
=========
دمج الـ features (مثلاً: مسار مكاني/static + مسار زمني/temporal) قبل رأس التصنيف.

القرار في implementation_plan.md: Concatenation + Linear projection هو الأنسب
لحجم الداتا الحالي. Tensor-Train / low-rank fusion اتم رفضه لأنه over-parameterized
وبيزوّد خطر overfitting من غير فايدة حقيقية على داتا بالحجم ده — ملحوظ هنا كتوثيق
للقرار فقط، مش متاح كخيار في الكود.
"""

import torch
import torch.nn as nn


class ConcatFusion(nn.Module):
    def __init__(self, input_dims, output_dim: int):
        super().__init__()
        total_dim = sum(input_dims)
        self.proj = nn.Sequential(
            nn.Linear(total_dim, output_dim),
            nn.GELU(),
        )
        self.output_dim = output_dim

    def forward(self, *features: torch.Tensor) -> torch.Tensor:
        x = torch.cat(features, dim=-1)
        return self.proj(x)


def build_fusion(kind: str, input_dims, output_dim: int) -> nn.Module:
    kind = kind.lower()
    if kind == "concat":
        return ConcatFusion(input_dims, output_dim)
    raise ValueError(
        f"Unsupported fusion type '{kind}'. Only 'concat' is supported "
        "(tensor-train/low-rank fusion rejected per implementation_plan.md)."
    )
