"""
test_fer2013.py
================
يتحقق من:
  1) تحميل الصور والـ labels صح من هيكل train/<class> و test/<class>.
  2) dedup داخل الـ split بيشيل التكرار الداخلي (img متطابق المحتوى).
  3) cross-split dedup بيشيل أي صورة train متطابقة المحتوى مع صورة في test.

يتطلب torch/torchvision مُثبّتين (شوف ملاحظة conftest.py).
"""

import pytest

torch = pytest.importorskip("torch")  # يتخطى الاختبار برسالة واضحة لو torch مش متاح

from emotionvia_v2.data.datasets.fer2013 import FER2013Dataset  # noqa: E402

CLASS_NAMES = ["angry", "disgust", "fear", "happy", "neutral", "sad", "surprise"]


def test_loads_correct_number_of_samples_without_dedup(fer2013_root):
    ds = FER2013Dataset(
        root_dir=str(fer2013_root), class_names=CLASS_NAMES, split="train",
        dedup=False, cross_split_dedup=False,
    )
    # 7 classes * 3 imgs + 1 dup.jpg (happy) + 1 leak.jpg (neutral) = 23
    assert len(ds) == 23


def test_within_split_dedup_removes_exact_duplicate(fer2013_root):
    ds = FER2013Dataset(
        root_dir=str(fer2013_root), class_names=CLASS_NAMES, split="train",
        dedup=True, cross_split_dedup=False,
    )
    # dup.jpg نفس محتوى happy/img_0.jpg بالظبط -> لازم يتشال واحد منهم
    assert len(ds) == 22


def test_cross_split_leakage_removed_from_train(fer2013_root):
    ds = FER2013Dataset(
        root_dir=str(fer2013_root), class_names=CLASS_NAMES, split="train",
        dedup=True, cross_split_dedup=True,
    )
    # leak.jpg (train/neutral) نفسه leak_copy.jpg (test/neutral) -> يتشال من train
    assert len(ds) == 21


def test_getitem_returns_tensor_and_valid_label(fer2013_root):
    ds = FER2013Dataset(root_dir=str(fer2013_root), class_names=CLASS_NAMES, split="test")
    img, label = ds[0]
    assert img.shape[0] == 3  # 3 قنوات بعد التحويل الافتراضي (channels=3)
    assert 0 <= label < len(CLASS_NAMES)
