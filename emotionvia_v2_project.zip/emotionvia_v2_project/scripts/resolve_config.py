r"""
resolve_config.py
==================
سكريبت تحقق يدوي (Manual Verification من implementation_plan.md).
بيحمّل الـ config، يطبعه بعد الحل (resolved)، ويتأكد إن مسارات الداتاسيتس
(البيئية عبر env vars) موجودة فعليًا على القرص قبل ما تبدأ تدريب طويل وتكتشف
غلطة مسار بعد نص ساعة تحميل.

تشغيل:
    export EMOTIONVIA_EMOPOI_ROOT=/content/emotionvia_v2/EmoPOI
    export EMOTIONVIA_FER2013_ROOT=/content/emotionvia_v2/FER-2013
    export EMOTIONVIA_RAFDB_ROOT=/content/emotionvia_v2/RAF-DB\ DATASET/DATASET
    export EMOTIONVIA_RAFDB_TRAIN_CSV=/content/.../train_labels.csv
    export EMOTIONVIA_RAFDB_TEST_CSV=/content/.../test_labels.csv
    python scripts/resolve_config.py --experiment baseline_v1
"""

import argparse
import sys
from pathlib import Path

# يسمح بتشغيل السكريبت مباشرة من جذر المشروع بدون تثبيت الباكدج
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from emotionvia_v2.config import load_config  # noqa: E402


def check_path(label: str, path_str: str) -> bool:
    if not path_str or "${" in str(path_str):
        print(f"  ✗ {label}: env var غير مُعرّف ({path_str})")
        return False
    exists = Path(path_str).exists()
    mark = "✓" if exists else "✗"
    print(f"  {mark} {label}: {path_str}  {'(موجود)' if exists else '(غير موجود!)'}")
    return exists


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--experiment", default="baseline_v1")
    parser.add_argument("--configs-dir", default="configs")
    args = parser.parse_args()

    cfg = load_config(experiment_name=args.experiment, configs_dir=args.configs_dir)

    print("=" * 70)
    print(f"Resolved config for experiment: {args.experiment}")
    print("=" * 70)
    print(cfg)
    print("=" * 70)

    print("\nChecking dataset paths on disk …\n")
    all_ok = True
    all_ok &= check_path("EmoPOI root", cfg.dataset.emopoi.root_dir)
    all_ok &= check_path("FER-2013 root", cfg.dataset.fer2013.root_dir)
    all_ok &= check_path("RAF-DB root", cfg.dataset.rafdb.root_dir)
    all_ok &= check_path("RAF-DB train_labels.csv", cfg.dataset.rafdb.train_csv)
    all_ok &= check_path("RAF-DB test_labels.csv", cfg.dataset.rafdb.test_csv)

    print()
    if all_ok:
        print("✅ كل المسارات موجودة — جاهز للتدريب.")
    else:
        print("⚠️  فيه مسارات ناقصة أو env vars مش متعرّفة. راجع الـ export commands "
              "في أعلى هذا الملف وتأكد إنها مطابقة لمكان فك ضغط الداتاسيتس عندك.")
        sys.exit(1)


if __name__ == "__main__":
    main()
