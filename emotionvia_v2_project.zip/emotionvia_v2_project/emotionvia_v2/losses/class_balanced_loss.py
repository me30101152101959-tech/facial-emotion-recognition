"""
class_balanced_loss.py
=======================
Class-Balanced weighting بناءً على "effective number of samples":
    E_n = (1 - beta^n) / (1 - beta)
    w_c \\propto 1 / E_n

بيختلف عن الـ inverse-frequency العادي (1/N_c) في إنه بيفترض إن كل عيّنة إضافية
لفئة معينة بتضيف معلومة أقل تدريجيًا (تشبّع/تداخل)، فبيدّي موازنة أكثر واقعية
من الـ inverse-frequency الخام خصوصًا مع imbalance شديد (17x هنا).

الاستخدام المقترح في الخطة: Focal Loss + Class-Balanced weights مع بعض.
"""

from typing import List

import torch


def compute_class_balanced_weights(
    samples_per_class: List[int], beta: float = 0.9999
) -> torch.Tensor:
    samples_per_class_t = torch.tensor(samples_per_class, dtype=torch.float32).clamp(min=1)
    effective_num = 1.0 - torch.pow(beta, samples_per_class_t)
    weights = (1.0 - beta) / effective_num
    # نطبّع بحيث متوسط الأوزان = 1 (يحافظ على مقياس الـ loss مستقر عبر التجارب)
    weights = weights / weights.sum() * len(samples_per_class)
    return weights
