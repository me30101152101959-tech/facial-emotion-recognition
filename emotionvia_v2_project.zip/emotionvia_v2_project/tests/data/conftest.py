"""
conftest.py
===========
Fixtures بتبني نسخ صناعية صغيرة جدًا (synthetic) من هيكل الداتاسيتس الثلاثة على
القرص المؤقت (tmp_path)، عشان نختبر منطق الـ Dataset classes (المسارات، الـ
labels، الـ dedup، الـ subject-wise split) من غير الحاجة لتحميل الداتا الحقيقية
(35K+ صورة) في كل تشغيلة اختبار.

ملحوظة: تشغيل الاختبارات دي محتاج torch + torchvision مُثبّتين (requirements.txt).
لم يتم تشغيلها فعليًا في بيئة بناء هذا الكود لعدم توفر GPU/إنترنت هناك — تم فحص
صحة الكود نحويًا فقط (py_compile). شغّلها على جهازك/Colab بعد `pip install -r
requirements.txt` للتأكد الكامل.
"""

from pathlib import Path

import pytest
from PIL import Image


def _make_image(path: Path, color=(128, 128, 128), size=(48, 48)):
    path.parent.mkdir(parents=True, exist_ok=True)
    Image.new("RGB", size, color=color).save(path)


@pytest.fixture
def fer2013_root(tmp_path):
    root = tmp_path / "FER-2013"
    classes = ["angry", "disgust", "fear", "happy", "neutral", "sad", "surprise"]
    for split in ("train", "test"):
        for i, cname in enumerate(classes):
            for j in range(3):
                _make_image(root / split / cname / f"img_{j}.jpg", color=(i * 10, j * 10, 50))
    # صورة مكررة بالظبط داخل train/happy (نفس المحتوى، اسم مختلف)
    _make_image(root / "train" / "happy" / "dup.jpg", color=(30, 0, 50))  # نفس لون img_0 في happy (i=3,j=0)
    # صورة مكررة عابرة بين train وtest (نفس محتوى بالظبط) -> تسريب بيانات
    _make_image(root / "train" / "neutral" / "leak.jpg", color=(4 * 10, 5, 50))
    _make_image(root / "test" / "neutral" / "leak_copy.jpg", color=(4 * 10, 5, 50))
    return root


@pytest.fixture
def rafdb_root_and_csv(tmp_path):
    root = tmp_path / "RAF-DB" / "DATASET"
    class_names = ["Anger", "Disgust", "Fear", "Happy", "Neutral", "Sad", "Surprise"]

    train_csv_lines = ["image,label"]
    for i in range(1, 8):  # labels 1..7
        (root / "train" / str(i)).mkdir(parents=True, exist_ok=True)
        for j in range(2):
            fname = f"train_{i}_{j}.jpg"
            _make_image(root / "train" / str(i) / fname, color=(i * 5, j * 5, 20))
            train_csv_lines.append(f"{fname},{i}")

    test_csv_lines = ["image,label"]
    for i in range(1, 8):
        (root / "test" / str(i)).mkdir(parents=True, exist_ok=True)
        fname = f"test_{i}_0.jpg"
        _make_image(root / "test" / str(i) / fname, color=(i * 7, 3, 20))
        test_csv_lines.append(f"{fname},{i}")

    train_csv = tmp_path / "train_labels.csv"
    test_csv = tmp_path / "test_labels.csv"
    train_csv.write_text("\n".join(train_csv_lines))
    test_csv.write_text("\n".join(test_csv_lines))

    return root, str(train_csv), str(test_csv), class_names


@pytest.fixture
def emopoi_root(tmp_path):
    root = tmp_path / "EmoPOI"
    class_names = ["Bored", "Excited", "Exhausted", "Frustrated", "Happy", "Neutral", "Sad", "Worried"]

    # 6 أشخاص، كل واحد عنده 4 فريمات في فئة "Happy" وفئة "Sad"
    for pid in range(1, 7):
        for cname in ("Happy", "Sad"):
            for fid in range(4):
                _make_image(
                    root / cname / f"person_{pid}_{fid}.png",
                    color=(pid * 20, fid * 20, 10),
                )
    return root, class_names
