"""
dedup.py
========
أدوات اكتشاف وحذف الصور المكررة (exact duplicates) داخل نفس الـ split أو
عبر splits مختلفة (cross-split leakage) — بناءً على النتائج في implementation_plan.md:
  - EmoPOI:    122 تكرار (إطارات متتالية)
  - FER-2013:  1,853 تكرار (بعضها عابر بين train/test -> تسريب بيانات خطير)
  - RAF-DB:    3 تكرارات فقط

المنطق: نحسب hash دقيق (MD5) لمحتوى البكسلات الخام لكل صورة (بعد توحيد الحجم ووضع
اللون) فنضمن إن نفس المحتوى بالظبط بيدّي نفس الـ hash بغض النظر عن اسم الملف.
"""

import hashlib
from pathlib import Path
from typing import Dict, Iterable, List, Set, Tuple

from PIL import Image


def _image_hash(path: Path, hash_size: int = 64) -> str:
    """
    MD5 hash لمحتوى الصورة الفعلي (pixel-exact) بعد توحيد المقاس ووضع اللون RGB.

    ملحوظة مهمة: كنا في نسخة أولى بنحوّل لـ grayscale ("L") قبل الـ hash، لكن ده
    بيفقد معلومة اللون -> صورتين مختلفتين فعليًا (ألوان مختلفة) بنفس درجة الإضاءة
    (luminance) ممكن تتحسب "مكررة" غلط وتتحذف من الداتا بالخطأ. استخدام RGB بيحل
    المشكلة دي مع الحفاظ على المقارنة الموحّدة عبر الداتاسيتس (الصور الرمادية
    المحوّلة لـ RGB بتكرار القناة هتفضل تدّي hash ثابت ومتّسق مع نفسها).
    """
    with Image.open(path) as img:
        img = img.convert("RGB").resize((hash_size, hash_size))
        data = img.tobytes()
    return hashlib.md5(data).hexdigest()


def find_exact_duplicates(paths: Iterable[Path]) -> Dict[str, List[Path]]:
    """يرجّع dict: hash -> list of paths (لو أكتر من مسار لنفس الـ hash يبقى تكرار)."""
    buckets: Dict[str, List[Path]] = {}
    for p in paths:
        h = _image_hash(p)
        buckets.setdefault(h, []).append(p)
    return {h: v for h, v in buckets.items() if len(v) > 1}


def dedup_within_split(paths: List[Path]) -> Tuple[List[Path], int]:
    """
    يحذف التكرارات الداخلية في نفس الـ split (يحتفظ بأول ظهور فقط، ترتيب مستقر).
    يرجّع (القائمة بعد التنظيف، عدد الصور المحذوفة).
    """
    seen: Set[str] = set()
    kept: List[Path] = []
    removed = 0
    for p in paths:
        h = _image_hash(p)
        if h in seen:
            removed += 1
            continue
        seen.add(h)
        kept.append(p)
    return kept, removed


def remove_cross_split_leakage(
    train_paths: List[Path], test_paths: List[Path]
) -> Tuple[List[Path], int]:
    """
    أخطر حالة: نفس الصورة (نفس المحتوى بالظبط) موجودة في train وtest معًا.
    لازم نشيلها من الـ train (نحافظ على نظافة test set كمرجع تقييم غير متحيّز).
    يرجّع (train بعد التنظيف، عدد الصور المحذوفة من train).
    """
    test_hashes: Set[str] = {_image_hash(p) for p in test_paths}
    kept: List[Path] = []
    removed = 0
    for p in train_paths:
        if _image_hash(p) in test_hashes:
            removed += 1
            continue
        kept.append(p)
    return kept, removed
