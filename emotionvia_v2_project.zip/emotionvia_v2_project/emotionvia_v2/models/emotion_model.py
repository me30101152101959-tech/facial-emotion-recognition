"""
emotion_model.py
================
الموديل الموحّد اللي بيجمع كل مكوّنات implementation_plan.md في مكان واحد:

  input --> Backbone (+ CBAM اختياري على الـ feature map المكاني) --> pooled vector
        --> [لو is_sequence] Temporal module (BiLSTM/TCN/Transformer) عبر الفريمات
        --> Head (MLP) --> logits

- بيدعم مُدخلين: صورة واحدة [B,C,H,W] (frame-level) أو sequence [B,T,C,H,W].
- CBAM بيتفعّل بس لو الـ backbone بيرجّع spatial feature map (CNNs). للـ
  Transformers (Swin/ViT) بيتعطّل تلقائيًا مع warning، لأن دول أصلًا عندهم
  self-attention داخلي وبيرجعوا embedding بعد pooling مش feature map مكاني.
"""

import warnings

import torch
import torch.nn as nn

from emotionvia_v2.models.attention import CBAM, SqueezeExcitation
from emotionvia_v2.models.backbone import build_backbone
from emotionvia_v2.models.temporal import build_temporal_module


class EmotionViAModel(nn.Module):
    def __init__(
        self,
        num_classes: int,
        backbone: str = "efficientnet_v2_s",
        pretrained: bool = True,
        freeze_backbone_epochs: int = 0,
        use_attention: bool = True,
        attention_type: str = "cbam",       # none | se | cbam
        cbam_reduction: int = 16,
        use_temporal: bool = False,
        temporal_type: str = "bilstm",      # bilstm | tcn | transformer
        temporal_hidden_dim: int = 256,
        temporal_num_layers: int = 1,
        head_hidden_dim: int = 256,
        dropout: float = 0.4,
    ):
        super().__init__()
        bb = build_backbone(backbone, pretrained=pretrained)
        self.feature_extractor = bb.feature_extractor
        self.pool = bb.pool
        self.feat_dim = bb.feat_dim
        self.is_spatial = bb.is_spatial
        self.backbone_name = backbone
        self.freeze_backbone_epochs = freeze_backbone_epochs

        # --- Attention ---
        self.attention = None
        if use_attention and attention_type != "none":
            if not self.is_spatial:
                warnings.warn(
                    f"backbone '{backbone}' لا يرجّع spatial feature map -> "
                    f"تم تعطيل {attention_type.upper()} تلقائيًا لهذا الـ backbone."
                )
            elif attention_type == "cbam":
                self.attention = CBAM(self.feat_dim, reduction=cbam_reduction)
            elif attention_type == "se":
                self.attention = SqueezeExcitation(self.feat_dim, reduction=cbam_reduction)
            else:
                raise ValueError(f"Unknown attention_type: {attention_type}")

        # --- Temporal (اختياري) ---
        self.use_temporal = use_temporal
        if use_temporal:
            self.temporal = build_temporal_module(
                temporal_type, input_dim=self.feat_dim,
                hidden_dim=temporal_hidden_dim, num_layers=temporal_num_layers,
            )
            head_in_dim = self.temporal.output_dim
        else:
            self.temporal = None
            head_in_dim = self.feat_dim

        # --- Head ---
        self.head = nn.Sequential(
            nn.BatchNorm1d(head_in_dim),
            nn.Linear(head_in_dim, head_hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(head_hidden_dim, num_classes),
        )

    # ---------- backbone freezing (gradual fine-tuning) ----------
    def set_backbone_trainable(self, trainable: bool):
        for p in self.feature_extractor.parameters():
            p.requires_grad = trainable

    def maybe_unfreeze(self, current_epoch: int):
        """يُستدعى في بداية كل epoch من الـ Trainer لفك تجميد الـ backbone تدريجيًا."""
        if self.freeze_backbone_epochs > 0 and current_epoch == self.freeze_backbone_epochs + 1:
            self.set_backbone_trainable(True)
            return True
        return False

    # ---------- single-frame encoding ----------
    def _encode_frame(self, x: torch.Tensor) -> torch.Tensor:
        """x: [B, C, H, W] -> pooled feature vector [B, feat_dim]."""
        feats = self.feature_extractor(x)
        if self.is_spatial:
            if self.attention is not None:
                feats = self.attention(feats)
            feats = self.pool(feats)
        # للـ transformers: feature_extractor أصلاً بيرجّع [B, feat_dim] مباشرة
        return feats

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if self.use_temporal:
            # x: [B, T, C, H, W]
            b, t, c, h, w = x.shape
            x = x.view(b * t, c, h, w)
            feats = self._encode_frame(x)          # [B*T, feat_dim]
            feats = feats.view(b, t, -1)            # [B, T, feat_dim]
            pooled = self.temporal(feats)            # [B, temporal_output_dim]
        else:
            # x: [B, C, H, W]  (frame-level)
            pooled = self._encode_frame(x)

        return self.head(pooled)

    def count_params(self) -> int:
        return sum(p.numel() for p in self.parameters() if p.requires_grad)
