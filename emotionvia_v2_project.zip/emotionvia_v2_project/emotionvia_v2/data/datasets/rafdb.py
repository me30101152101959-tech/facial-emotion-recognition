"""
rafdb.py
========
RAF-DB DATASET/DATASET/<train|test>/<1..7>/*.jpg  مع train_labels.csv / test_labels.csv
الـ CSV: image,label (label رقم 1-7) -> يتحوّل لـ 0-based داخليًا.

أنظف داتاسيت من الثلاثة (3 تكرارات فقط فقط) — dedup هنا احترازي بالأساس.
"""

import csv
from pathlib import Path
from typing import Callable, List, Optional, Tuple

from PIL import Image
from torch.utils.data import Dataset

from emotionvia_v2.data.dedup import dedup_within_split
from emotionvia_v2.data.transforms import build_transform


class RAFDBDataset(Dataset):
    def __init__(
        self,
        root_dir: str,
        csv_path: str,
        class_names: List[str],
        split: str = "train",
        image_size: Tuple[int, int] = (224, 224),
        channels: int = 3,
        label_base: int = 1,
        dedup: bool = True,
        transform: Optional[Callable] = None,
    ):
        assert split in ("train", "test")
        self.root_dir = Path(root_dir)
        self.class_names = class_names
        self.split = split
        self.transform = transform or build_transform(
            image_size=image_size, channels=channels, train=(split == "train")
        )

        csv_map = self._read_csv(csv_path, label_base)
        self.samples: List[Tuple[Path, int]] = self._match_images(csv_map)

        if dedup:
            paths = [p for p, _ in self.samples]
            kept_paths, removed = dedup_within_split(paths)
            kept_set = set(kept_paths)
            before = len(self.samples)
            self.samples = [(p, l) for p, l in self.samples if p in kept_set]
            print(f"[RAF-DB:{split}] dedup removed {before - len(self.samples)} images "
                  f"(expected ~3 total across the dataset)")

    @staticmethod
    def _read_csv(csv_path: str, label_base: int) -> dict:
        csv_map = {}
        with open(csv_path, newline="") as f:
            reader = csv.DictReader(f)
            for row in reader:
                fname = row["image"].strip()
                raw_label = int(row["label"].strip())
                csv_map[fname] = raw_label - label_base  # 1..7 -> 0..6
        return csv_map

    def _match_images(self, csv_map: dict) -> List[Tuple[Path, int]]:
        samples = []
        split_root = self.root_dir / self.split
        if not split_root.is_dir():
            return samples
        for label_folder in split_root.iterdir():
            if not label_folder.is_dir():
                continue
            for ext in ("*.jpg", "*.jpeg", "*.png"):
                for img_path in label_folder.glob(ext):
                    label = csv_map.get(img_path.name)
                    if label is not None and 0 <= label < len(self.class_names):
                        samples.append((img_path, label))
        return samples

    def __len__(self) -> int:
        return len(self.samples)

    def __getitem__(self, idx: int):
        path, label = self.samples[idx]
        img = Image.open(path)
        img = self.transform(img)
        return img, label
