"""
backbone.py
===========
Factory موحّد لبناء أي backbone من الجدول المقارن في implementation_plan.md.

مهم: عشان CBAM (attention مكاني+قنوات) يشتغل صح، لازم ناخد الـ feature map
المكاني [B, C, H, W] *قبل* الـ global pooling النهائي. لو استخدمنا الموديل
الكامل زي ما هو (base(x)) هيرجّع متجه [B, D] بعد pooling داخلي، وده يبطّل فايدة
CBAM. فبنفصل هنا feature_extractor (الجزء المكاني) عن الـ pooling.

CNN_BACKBONES تدعم spatial features -> CBAM شغّال.
TRANSFORMER_BACKBONES (Swin/ViT) بترجّع embeddings مباشرة بعد الـ pooling
الداخلي بتاعها -> CBAM بيتعطّل تلقائيًا لها (مفيش فايدة من دمجه مع
self-attention أصلاً، شوف الملاحظة في emotion_model.py).
"""

from typing import NamedTuple

import torch.nn as nn
from torchvision import models

CNN_BACKBONES = {"resnet18", "resnet50", "efficientnet_v2_s", "convnext_tiny", "mobilenet_v3_large"}
TRANSFORMER_BACKBONES = {"swin_t", "vit_b_16"}


class BackboneOutput(NamedTuple):
    feature_extractor: nn.Module   # x -> spatial map [B,C,H,W]  (CNN)  أو  pooled [B,D]  (Transformer)
    pool: nn.Module                # spatial map -> [B, feat_dim]  (Identity للـ transformers)
    feat_dim: int
    is_spatial: bool               # True لو الـ feature_extractor بيرجّع [B,C,H,W]


def build_backbone(name: str, pretrained: bool = True) -> BackboneOutput:
    name = name.lower()

    if name in ("resnet18", "resnet50"):
        if name == "resnet18":
            weights = models.ResNet18_Weights.IMAGENET1K_V1 if pretrained else None
            base = models.resnet18(weights=weights)
        else:
            weights = models.ResNet50_Weights.IMAGENET1K_V2 if pretrained else None
            base = models.resnet50(weights=weights)
        feat_dim = base.fc.in_features
        feature_extractor = nn.Sequential(
            base.conv1, base.bn1, base.relu, base.maxpool,
            base.layer1, base.layer2, base.layer3, base.layer4,
        )
        pool = nn.Sequential(nn.AdaptiveAvgPool2d(1), nn.Flatten(1))
        return BackboneOutput(feature_extractor, pool, feat_dim, True)

    if name == "efficientnet_v2_s":
        weights = models.EfficientNet_V2_S_Weights.IMAGENET1K_V1 if pretrained else None
        base = models.efficientnet_v2_s(weights=weights)
        feat_dim = base.classifier[1].in_features
        feature_extractor = base.features
        pool = nn.Sequential(nn.AdaptiveAvgPool2d(1), nn.Flatten(1))
        return BackboneOutput(feature_extractor, pool, feat_dim, True)

    if name == "convnext_tiny":
        weights = models.ConvNeXt_Tiny_Weights.IMAGENET1K_V1 if pretrained else None
        base = models.convnext_tiny(weights=weights)
        feat_dim = base.classifier[2].in_features
        feature_extractor = base.features
        pool = nn.Sequential(nn.AdaptiveAvgPool2d(1), nn.Flatten(1))
        return BackboneOutput(feature_extractor, pool, feat_dim, True)

    if name == "mobilenet_v3_large":
        weights = models.MobileNet_V3_Large_Weights.IMAGENET1K_V2 if pretrained else None
        base = models.mobilenet_v3_large(weights=weights)
        feat_dim = base.classifier[0].in_features
        feature_extractor = base.features
        pool = nn.Sequential(nn.AdaptiveAvgPool2d(1), nn.Flatten(1))
        return BackboneOutput(feature_extractor, pool, feat_dim, True)

    if name == "swin_t":
        weights = models.Swin_T_Weights.IMAGENET1K_V1 if pretrained else None
        base = models.swin_t(weights=weights)
        feat_dim = base.head.in_features
        base.head = nn.Identity()
        return BackboneOutput(base, nn.Identity(), feat_dim, False)

    if name == "vit_b_16":
        weights = models.ViT_B_16_Weights.IMAGENET1K_V1 if pretrained else None
        base = models.vit_b_16(weights=weights)
        feat_dim = base.heads.head.in_features
        base.heads = nn.Identity()
        return BackboneOutput(base, nn.Identity(), feat_dim, False)

    raise ValueError(
        f"Unknown backbone '{name}'. Supported: "
        f"{sorted(CNN_BACKBONES | TRANSFORMER_BACKBONES)}"
    )
