"""
emopoi.py
=========
EmoPOI/<ClassFolder>/person_<ID>_<FrameID>.png

نقاط حرجة (implementation_plan.md):
1) الـ split لازم يكون subject-wise (بالـ person_id) مش عشوائي — لأن الفريمات
   متتالية زمنيًا لنفس الشخص، والـ split العشوائي بيسرّب فريمات متجاورة بين
   train/val (نفس الوجه تقريبًا في الاتنين) -> accuracy وهمية أعلى من الحقيقي.
2) 122 تكرار (إطارات متجاورة متطابقة تقريبًا) -> dedup اختياري (exact-match فقط،
   مش near-duplicate، عشان منحذفش فريمات مختلفة فعليًا بالغلط).
3) is_sequence=True: بيجمع الفريمات بترتيبها الزمني لكل (person, session) في
   tensor واحد [T, C, H, W] عشان تتغذّى لموديل زمني (BiLSTM/TCN) — شوف
   emotionvia_v2/models/temporal.py.
"""

import random
import re
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

import torch
from PIL import Image
from torch.utils.data import Dataset

from emotionvia_v2.data.dedup import dedup_within_split
from emotionvia_v2.data.transforms import build_transform

_FRAME_RE = re.compile(r"^person_(\d+)_(\d+)")


class EmoPOIDataset(Dataset):
    def __init__(
        self,
        root_dir: str,
        class_names: List[str],
        split: str = "train",           # "train" | "val" | "test"
        image_size: Tuple[int, int] = (224, 224),
        channels: int = 3,
        is_sequence: bool = False,
        sequence_length: int = 8,
        val_frac: float = 0.15,
        test_frac: float = 0.10,
        seed: int = 42,
        dedup: bool = True,
        transform: Optional[Callable] = None,
    ):
        assert split in ("train", "val", "test")
        self.root_dir = Path(root_dir)
        self.class_names = class_names
        self.split = split
        self.is_sequence = is_sequence
        self.sequence_length = sequence_length
        self.transform = transform or build_transform(
            image_size=image_size, channels=channels, train=(split == "train")
        )

        records = self._scan(dedup=dedup)  # (path, label_idx, person_id, frame_id)
        split_map = self._subject_wise_split(records, val_frac, test_frac, seed)
        self.records = [r for r in records if split_map[r[2]] == split]

        if is_sequence:
            self.sequences = self._group_sequences(self.records)
        else:
            self.samples = [(p, l) for p, l, _, _ in self.records]

    # ---------- scanning ----------
    def _scan(self, dedup: bool) -> List[Tuple[Path, int, str, int]]:
        records = []
        for label_idx, cname in enumerate(self.class_names):
            cdir = self.root_dir / cname
            if not cdir.is_dir():
                continue
            paths = sorted(cdir.glob("*.png"))
            if dedup:
                paths, removed = dedup_within_split(paths)
                if removed:
                    print(f"[EmoPOI] dedup removed {removed} images in class '{cname}'")
            for p in paths:
                m = _FRAME_RE.match(p.stem)
                pid = m.group(1) if m else "unknown"
                fid = int(m.group(2)) if m else 0
                records.append((p, label_idx, pid, fid))
        return records

    # ---------- subject-wise split ----------
    @staticmethod
    def _subject_wise_split(
        records: List[Tuple[Path, int, str, int]], val_frac: float, test_frac: float, seed: int
    ) -> Dict[str, str]:
        pids = sorted({r[2] for r in records})
        rng = random.Random(seed)
        rng.shuffle(pids)
        n = len(pids)
        n_test = max(1, int(n * test_frac))
        n_val = max(1, int(n * val_frac))
        split_map = {}
        for i, pid in enumerate(pids):
            if i < n_test:
                split_map[pid] = "test"
            elif i < n_test + n_val:
                split_map[pid] = "val"
            else:
                split_map[pid] = "train"
        return split_map

    # ---------- sequence grouping ----------
    def _group_sequences(
        self, records: List[Tuple[Path, int, str, int]]
    ) -> List[Tuple[List[Path], int]]:
        """يجمع فريمات نفس (person, class) مرتبة زمنيًا، ويقسّمها لنوافذ بطول sequence_length."""
        by_key: Dict[Tuple[str, int], List[Tuple[int, Path]]] = {}
        for p, label, pid, fid in records:
            by_key.setdefault((pid, label), []).append((fid, p))

        sequences = []
        for (pid, label), frames in by_key.items():
            frames.sort(key=lambda x: x[0])
            paths = [p for _, p in frames]
            for start in range(0, max(1, len(paths) - self.sequence_length + 1), self.sequence_length):
                window = paths[start:start + self.sequence_length]
                if len(window) < self.sequence_length:
                    # padding بتكرار آخر فريم بدل حذف نافذة قصيرة
                    window = window + [window[-1]] * (self.sequence_length - len(window))
                sequences.append((window, label))
        return sequences

    def __len__(self) -> int:
        return len(self.sequences) if self.is_sequence else len(self.samples)

    def __getitem__(self, idx: int):
        if self.is_sequence:
            paths, label = self.sequences[idx]
            frames = [self.transform(Image.open(p)) for p in paths]
            return torch.stack(frames, dim=0), label  # [T, C, H, W]
        path, label = self.samples[idx]
        img = Image.open(path)
        return self.transform(img), label
