"""
fer2013.py
==========
FER-2013/train/<class>/*.jpg  و  FER-2013/test/<class>/*.jpg

معالجة خاصة (implementation_plan.md):
- 1,853 تكرار exact-duplicate، وبعضها عابر بين train/test -> تسريب بيانات.
  بنعمل: (1) dedup داخلي لكل split، (2) إزالة أي صورة train موجودة نفس محتواها
  في test (cross-split leakage removal) — إلزامي عشان نقيس أداء حقيقي غير متحيّز.
- imbalance شديد (disgust=436 مقابل happy=7215، نسبة 16.5x) -> يُعالَج على مستوى
  الـ Trainer عبر sampler/loss، مش هنا في الـ Dataset.
"""

from pathlib import Path
from typing import Callable, List, Optional, Tuple

from PIL import Image
from torch.utils.data import Dataset

from emotionvia_v2.data.dedup import dedup_within_split, remove_cross_split_leakage
from emotionvia_v2.data.transforms import build_transform


class FER2013Dataset(Dataset):
    def __init__(
        self,
        root_dir: str,
        class_names: List[str],
        split: str = "train",
        image_size: Tuple[int, int] = (224, 224),
        channels: int = 3,
        grayscale_mean: Optional[float] = None,
        grayscale_std: Optional[float] = None,
        dedup: bool = True,
        cross_split_dedup: bool = True,
        transform: Optional[Callable] = None,
    ):
        assert split in ("train", "test")
        self.root_dir = Path(root_dir)
        self.class_names = class_names
        self.split = split
        self.transform = transform or build_transform(
            image_size=image_size, channels=channels, train=(split == "train"),
            grayscale_mean=grayscale_mean, grayscale_std=grayscale_std,
        )

        self.samples: List[Tuple[Path, int]] = self._load_samples(
            dedup=dedup, cross_split_dedup=cross_split_dedup
        )

    def _list_split(self, split: str) -> List[Tuple[Path, int]]:
        records = []
        split_dir = self.root_dir / split
        for label_idx, cname in enumerate(self.class_names):
            cdir = split_dir / cname
            if not cdir.is_dir():
                continue
            for ext in ("*.jpg", "*.jpeg", "*.png"):
                for p in cdir.glob(ext):
                    records.append((p, label_idx))
        return records

    def _load_samples(self, dedup: bool, cross_split_dedup: bool) -> List[Tuple[Path, int]]:
        train_records = self._list_split("train")
        test_records = self._list_split("test")

        if dedup:
            train_paths, removed_tr = dedup_within_split([p for p, _ in train_records])
            test_paths, removed_te = dedup_within_split([p for p, _ in test_records])
            train_records = [(p, l) for p, l in train_records if p in set(train_paths)]
            test_records = [(p, l) for p, l in test_records if p in set(test_paths)]
            print(f"[FER2013] within-split dedup removed: train={removed_tr} test={removed_te}")

        if cross_split_dedup:
            train_paths = [p for p, _ in train_records]
            test_paths = [p for p, _ in test_records]
            clean_train_paths, removed_leak = remove_cross_split_leakage(train_paths, test_paths)
            clean_set = set(clean_train_paths)
            train_records = [(p, l) for p, l in train_records if p in clean_set]
            print(f"[FER2013] cross-split leakage removed from train: {removed_leak}")

        return train_records if self.split == "train" else test_records

    def __len__(self) -> int:
        return len(self.samples)

    def __getitem__(self, idx: int):
        path, label = self.samples[idx]
        img = Image.open(path)
        img = self.transform(img)
        return img, label
