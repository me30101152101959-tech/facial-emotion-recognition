"""
config.py
=========
تحميل ودمج ملفات YAML (dataset/*, model/backbone, experiment/<name>) في كائن
OmegaConf واحد، مع حل الـ environment-variable interpolations (${oc.env:...}).

بديل مباشر لـ hydra.main هنا تحديدًا لأن بيئة التطوير الحالية مالهاش إنترنت
لتثبيت hydra-core والتحقق عمليًا من سلوك الـ defaults-list composition بتاعتها.
النتيجة نفس فكرة الدمج، لكن بمسار تحميل صريح وواضح وسهل تتبّعه.
"""

from pathlib import Path

from omegaconf import OmegaConf, DictConfig


def load_config(experiment_name: str = "baseline_v1", configs_dir: str = "configs") -> DictConfig:
    configs_dir = Path(configs_dir)

    emopoi_cfg = OmegaConf.load(configs_dir / "dataset" / "emopoi.yaml").dataset
    fer_cfg = OmegaConf.load(configs_dir / "dataset" / "fer2013.yaml").dataset
    rafdb_cfg = OmegaConf.load(configs_dir / "dataset" / "rafdb.yaml").dataset
    model_cfg = OmegaConf.load(configs_dir / "model" / "backbone.yaml").model
    exp_path = configs_dir / "experiment" / f"{experiment_name}.yaml"
    if not exp_path.is_file():
        raise FileNotFoundError(f"Experiment config not found: {exp_path}")
    exp_cfg = OmegaConf.load(exp_path).experiment

    cfg = OmegaConf.create({
        "dataset": {"emopoi": emopoi_cfg, "fer2013": fer_cfg, "rafdb": rafdb_cfg},
        "model": model_cfg,
        "experiment": exp_cfg,
    })

    # يحل ${oc.env:VAR_NAME} و ${oc.env:VAR_NAME,default} لو موجودة كـ env vars،
    # وإلا بيسيبها placeholder (هنتأكد منها صراحة في scripts/resolve_config.py).
    OmegaConf.resolve(cfg)
    return cfg
