"""
test_emopoi.py
===============
يتحقق من أهم نقطة حرجة في الخطة: الـ subject-wise split — نفس الـ person_id
لازم يظهر في split واحد بس (train أو val أو test)، مش موزّع بينهم (وده اللي
بيمنع data leakage).
"""

import pytest

torch = pytest.importorskip("torch")

from emotionvia_v2.data.datasets.emopoi import EmoPOIDataset  # noqa: E402


def _person_ids(ds):
    ids = set()
    samples = ds.sequences if ds.is_sequence else ds.samples
    for item in samples:
        # frame-level: (path, label) | sequence: (list[path], label)
        path = item[0][0] if isinstance(item[0], list) else item[0]
        stem = path.stem  # e.g. person_3_1
        pid = stem.split("_")[1]
        ids.add(pid)
    return ids


def test_no_subject_overlap_between_splits(emopoi_root):
    root, class_names = emopoi_root
    kwargs = dict(root_dir=str(root), class_names=class_names, val_frac=0.34,
                  test_frac=0.17, seed=42, dedup=False)
    train_ds = EmoPOIDataset(split="train", **kwargs)
    val_ds = EmoPOIDataset(split="val", **kwargs)
    test_ds = EmoPOIDataset(split="test", **kwargs)

    train_ids = _person_ids(train_ds)
    val_ids = _person_ids(val_ds)
    test_ids = _person_ids(test_ds)

    assert train_ids.isdisjoint(val_ids)
    assert train_ids.isdisjoint(test_ids)
    assert val_ids.isdisjoint(test_ids)
    # كل الأشخاص الستة اتوزعوا (محدش اتفقد)
    assert train_ids | val_ids | test_ids == {"1", "2", "3", "4", "5", "6"}


def test_sequence_mode_groups_frames_chronologically(emopoi_root):
    root, class_names = emopoi_root
    ds = EmoPOIDataset(
        root_dir=str(root), class_names=class_names, split="train",
        is_sequence=True, sequence_length=4, val_frac=0.34, test_frac=0.17,
        seed=42, dedup=False,
    )
    assert len(ds) > 0
    frames, label = ds.sequences[0]
    fids = [int(p.stem.split("_")[2]) for p in frames]
    assert fids == sorted(fids)  # مرتبة زمنيًا
