"""
focal_loss.py
=============
Focal Loss: -alpha_t * (1 - p_t)^gamma * log(p_t)

بيقلّل وزن الأمثلة "السهلة" (اللي الموديل واثق فيها أصلًا) ويركّز التدريب على
الأمثلة الصعبة/النادرة — مهم هنا لأن imbalance وصل لـ 17x في RAF-DB/FER-2013
(implementation_plan.md)، والـ class weights العادية مش دايمًا كفاية.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


class FocalLoss(nn.Module):
    def __init__(self, alpha: torch.Tensor = None, gamma: float = 2.0,
                 label_smoothing: float = 0.0, reduction: str = "mean"):
        super().__init__()
        self.alpha = alpha            # per-class weights [num_classes] أو None
        self.gamma = gamma
        self.label_smoothing = label_smoothing
        self.reduction = reduction

    def forward(self, logits: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        ce = F.cross_entropy(
            logits, targets, weight=self.alpha,
            label_smoothing=self.label_smoothing, reduction="none",
        )
        p_t = torch.exp(-ce)  # احتمال الفئة الصحيحة
        focal_term = (1 - p_t) ** self.gamma
        loss = focal_term * ce

        if self.reduction == "mean":
            return loss.mean()
        if self.reduction == "sum":
            return loss.sum()
        return loss
