"""
transforms.py
=============
تحويلات موحّدة قابلة للتهيئة عبر config لكل داتاسيت.

قرارات مبنية على implementation_plan.md:
- EmoPOI و FER-2013 مصدرهم grayscale (1 قناة)، RAF-DB مصدره RGB (3 قنوات).
  عشان ندعم أوزان pretrained على ImageNet (اللي محتاجة 3 قنوات RGB)، بنكرر
  القناة الرمادية 3 مرات (channel replication) بدل ما نبني backbone بقناة واحدة
  مخصّصة (أسهل، وبيحافظ على الاستفادة الكاملة من transfer learning).
- لو channels=1 صراحة في الـ config (تجربة "low-resource" بدون pretrained)،
  بنستخدم إحصائيات الداتاسيت الفعلية (مثال FER-2013: mean=0.507, std=0.255)
  بدل إحصائيات ImageNet اللي مبنية على صور RGB طبيعية مش مناسبة لصور رمادية صغيرة.
"""

from typing import Optional, Tuple

from torchvision import transforms

IMAGENET_MEAN = [0.485, 0.456, 0.406]
IMAGENET_STD = [0.229, 0.224, 0.225]


def build_transform(
    image_size: Tuple[int, int] = (224, 224),
    channels: int = 3,
    train: bool = True,
    grayscale_mean: Optional[float] = None,
    grayscale_std: Optional[float] = None,
    strong_aug: bool = True,
):
    """
    channels=3  -> يحوّل أي صورة (رمادية أو RGB) لـ 3 قنوات + ImageNet normalization.
    channels=1  -> يفضّل رمادي بقناة واحدة + إحصائيات مخصصة (لازم تتمرر grayscale_mean/std).
    """
    ops = []

    if channels == 3:
        ops.append(transforms.Lambda(lambda img: img.convert("RGB")))
        mean, std = IMAGENET_MEAN, IMAGENET_STD
    elif channels == 1:
        ops.append(transforms.Lambda(lambda img: img.convert("L")))
        if grayscale_mean is None or grayscale_std is None:
            raise ValueError(
                "channels=1 يتطلب تمرير grayscale_mean/grayscale_std "
                "(محسوبة من الداتاسيت نفسه، شوف configs/dataset/fer2013.yaml)."
            )
        mean, std = [grayscale_mean], [grayscale_std]
    else:
        raise ValueError(f"channels must be 1 or 3, got {channels}")

    ops.append(transforms.Resize(image_size))

    if train:
        ops += [
            transforms.RandomHorizontalFlip(),
            transforms.RandomRotation(12),
        ]
        if strong_aug:
            ops.append(transforms.ColorJitter(0.3, 0.3, 0.15, 0.05))

    ops.append(transforms.ToTensor())
    ops.append(transforms.Normalize(mean, std))

    if train and strong_aug:
        ops.append(transforms.RandomErasing(p=0.25, scale=(0.02, 0.12)))

    return transforms.Compose(ops)
