"""early_stopping.py — يوقف التدريب لو مفيش تحسّن لعدد epochs محدد (patience)."""


class EarlyStopping:
    def __init__(self, patience: int = 7, mode: str = "max"):
        assert mode in ("max", "min")
        self.patience = patience
        self.mode = mode
        self.best_value = float("-inf") if mode == "max" else float("inf")
        self.num_bad_epochs = 0
        self.should_stop = False

    def step(self, value: float) -> bool:
        """يرجّع True لو الـ value الحالية أحسن قيمة لحد دلوقتي."""
        is_better = value > self.best_value if self.mode == "max" else value < self.best_value
        if is_better:
            self.best_value = value
            self.num_bad_epochs = 0
        else:
            self.num_bad_epochs += 1
            if self.num_bad_epochs >= self.patience:
                self.should_stop = True
        return is_better
