"""
evaluate.py
===========
يحمّل best_model.pt ويطلع كل صور المخرجات: منحنيات التدريب، Confusion Matrix،
Classification Report، عيّنات تنبؤات، وGrad-CAM — بنفس منطق النوتبوك لكن على
بنية المشروع الكاملة.

تشغيل:
    python -m emotionvia_v2.evaluate --experiment baseline_v1
"""

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
import torch
import torch.nn.functional as F
from sklearn.metrics import classification_report, confusion_matrix
from torch.utils.data import ConcatDataset, DataLoader

from emotionvia_v2.config import load_config
from emotionvia_v2.data.datasets.emopoi import EmoPOIDataset
from emotionvia_v2.data.datasets.fer2013 import FER2013Dataset
from emotionvia_v2.data.datasets.rafdb import RAFDBDataset
from emotionvia_v2.models.emotion_model import EmotionViAModel
from emotionvia_v2.train import EMOPOI_MAP, FER_MAP, RAFDB_MAP

INV_MEAN = torch.tensor([0.485, 0.456, 0.406]).view(3, 1, 1)
INV_STD = torch.tensor([0.229, 0.224, 0.225]).view(3, 1, 1)


def denorm(img_t: torch.Tensor) -> np.ndarray:
    img = img_t.cpu() * INV_STD + INV_MEAN
    return img.clamp(0, 1).permute(1, 2, 0).numpy()


class GradCAM:
    def __init__(self, model, target_layer):
        self.model = model
        self.gradients = None
        self.activations = None
        target_layer.register_forward_hook(self._save_activation)
        target_layer.register_full_backward_hook(self._save_gradient)

    def _save_activation(self, module, inp, out):
        self.activations = out.detach()

    def _save_gradient(self, module, grad_in, grad_out):
        self.gradients = grad_out[0].detach()

    def generate(self, x, class_idx=None):
        self.model.zero_grad()
        out = self.model(x)
        if class_idx is None:
            class_idx = out.argmax(1).item()
        out[0, class_idx].backward()
        weights = self.gradients.mean(dim=(2, 3), keepdim=True)
        cam = F.relu((weights * self.activations).sum(dim=1, keepdim=True))
        cam = F.interpolate(cam, size=x.shape[-2:], mode="bilinear", align_corners=False)
        cam = cam.squeeze().cpu().numpy()
        cam = (cam - cam.min()) / (cam.max() - cam.min() + 1e-8)
        return cam, class_idx


def build_val_loader(cfg):
    emopoi_val = EmoPOIDataset(
        root_dir=cfg.dataset.emopoi.root_dir, class_names=list(cfg.dataset.emopoi.class_names),
        split="val", image_size=tuple(cfg.dataset.emopoi.image_size),
        channels=cfg.dataset.emopoi.channels, val_frac=cfg.dataset.emopoi.val_frac,
        test_frac=cfg.dataset.emopoi.test_frac, seed=cfg.dataset.emopoi.seed,
        dedup=cfg.dataset.emopoi.dedup,
    )
    fer_val = FER2013Dataset(
        root_dir=cfg.dataset.fer2013.root_dir, class_names=list(cfg.dataset.fer2013.class_names),
        split="test", image_size=tuple(cfg.dataset.fer2013.image_size),
        channels=cfg.dataset.fer2013.channels, dedup=cfg.dataset.fer2013.dedup,
        cross_split_dedup=cfg.dataset.fer2013.cross_split_dedup,
    )
    raf_val = RAFDBDataset(
        root_dir=cfg.dataset.rafdb.root_dir, csv_path=cfg.dataset.rafdb.test_csv,
        class_names=list(cfg.dataset.rafdb.class_names), split="test",
        image_size=tuple(cfg.dataset.rafdb.image_size), channels=cfg.dataset.rafdb.channels,
        label_base=cfg.dataset.rafdb.label_base, dedup=cfg.dataset.rafdb.dedup,
    )

    unified_classes = list(cfg.experiment.unified_classes)
    cls2idx = {c: i for i, c in enumerate(unified_classes)}

    def remap(ds, local_names, mapping):
        remap_list = [cls2idx[mapping[n]] for n in local_names]
        ds.samples = [(p, remap_list[l]) for p, l in ds.samples]
        return ds

    remap(emopoi_val, list(cfg.dataset.emopoi.class_names), EMOPOI_MAP)
    remap(fer_val, list(cfg.dataset.fer2013.class_names), FER_MAP)
    remap(raf_val, list(cfg.dataset.rafdb.class_names), RAFDB_MAP)

    combined_val = ConcatDataset([emopoi_val, fer_val, raf_val])
    return DataLoader(combined_val, batch_size=cfg.experiment.training.batch_size, shuffle=False), unified_classes


def main(experiment_name: str = "baseline_v1", configs_dir: str = "configs"):
    cfg = load_config(experiment_name=experiment_name, configs_dir=configs_dir)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    output_dir = Path(cfg.experiment.output_dir)

    val_loader, unified_classes = build_val_loader(cfg)
    num_classes = len(unified_classes)

    model = EmotionViAModel(
        num_classes=num_classes, backbone=cfg.model.backbone, pretrained=False,
        use_attention=cfg.model.use_attention, attention_type=cfg.model.attention_type,
        cbam_reduction=cfg.model.cbam_reduction, use_temporal=cfg.model.use_temporal,
        temporal_type=cfg.model.temporal_type, temporal_hidden_dim=cfg.model.temporal_hidden_dim,
        temporal_num_layers=cfg.model.temporal_num_layers, head_hidden_dim=cfg.model.head_hidden_dim,
        dropout=cfg.model.dropout,
    ).to(device)

    ckpt = torch.load(output_dir / "best_model.pt", map_location=device)
    model.load_state_dict(ckpt["model_state"])
    model.eval()
    print(f"Loaded checkpoint from epoch {ckpt['epoch']}  (val_acc={ckpt['val_acc']:.3f})")

    # ---------- 1) training curves ----------
    hist = pd.read_csv(output_dir / "metrics.csv")
    fig, axes = plt.subplots(1, 2, figsize=(13, 4.5))
    axes[0].plot(hist["epoch"], hist["train_loss"], label="Train Loss", marker="o", ms=3)
    axes[0].plot(hist["epoch"], hist["val_loss"], label="Val Loss", marker="o", ms=3)
    axes[0].set_title("Loss"); axes[0].legend(); axes[0].grid(alpha=0.3)
    axes[1].plot(hist["epoch"], hist["train_acc"], label="Train Acc", marker="o", ms=3)
    axes[1].plot(hist["epoch"], hist["val_acc"], label="Val Acc", marker="o", ms=3)
    axes[1].set_title("Accuracy"); axes[1].legend(); axes[1].grid(alpha=0.3)
    plt.tight_layout()
    plt.savefig(output_dir / "training_curves.png", dpi=150)
    plt.close(fig)

    # ---------- 2) confusion matrix + classification report ----------
    all_preds, all_labels = [], []
    sample_x_store, sample_y_store = None, None
    with torch.no_grad():
        for x, y in val_loader:
            x = x.to(device)
            out = model(x)
            all_preds.extend(out.argmax(1).cpu().numpy())
            all_labels.extend(y.numpy())
            if sample_x_store is None:
                sample_x_store, sample_y_store = x, y

    cm = confusion_matrix(all_labels, all_preds, labels=list(range(num_classes)))
    cm_norm = cm.astype(float) / cm.sum(axis=1, keepdims=True).clip(min=1)
    plt.figure(figsize=(9, 7))
    sns.heatmap(cm_norm, annot=True, fmt=".2f", cmap="Blues",
                xticklabels=unified_classes, yticklabels=unified_classes)
    plt.title(f"Confusion Matrix — val_acc={ckpt['val_acc']:.3f}")
    plt.xlabel("Predicted"); plt.ylabel("True")
    plt.tight_layout()
    plt.savefig(output_dir / "confusion_matrix.png", dpi=150)
    plt.close()

    report = classification_report(all_labels, all_preds, target_names=unified_classes, digits=3)
    print("\n" + report)
    (output_dir / "classification_report.txt").write_text(report)

    # ---------- 3) sample predictions ----------
    with torch.no_grad():
        preds = model(sample_x_store.to(device)).argmax(1).cpu()
    n_show = min(12, len(sample_y_store))
    fig, axes = plt.subplots(3, 4, figsize=(13, 10))
    for i, ax in enumerate(axes.flat):
        if i >= n_show:
            ax.axis("off"); continue
        img = denorm(sample_x_store[i])
        correct = sample_y_store[i].item() == preds[i].item()
        ax.imshow(img)
        ax.set_title(f"True: {unified_classes[sample_y_store[i]]}\n"
                     f"Pred: {unified_classes[preds[i]]}",
                     fontsize=9, color=("green" if correct else "red"))
        ax.set_xticks([]); ax.set_yticks([])
    plt.tight_layout()
    plt.savefig(output_dir / "sample_predictions.png", dpi=150)
    plt.close(fig)

    # ---------- 4) Grad-CAM ----------
    if model.is_spatial:
        gradcam = GradCAM(model, model.feature_extractor[-1])
        n_examples = min(6, len(sample_y_store))
        fig, axes = plt.subplots(2, n_examples, figsize=(3 * n_examples, 6))
        for i in range(n_examples):
            x_i = sample_x_store[i:i + 1].to(device)
            img = denorm(x_i[0])
            cam, pred_idx = gradcam.generate(x_i)
            axes[0, i].imshow(img); axes[0, i].set_title(f"Pred: {unified_classes[pred_idx]}", fontsize=9)
            axes[0, i].axis("off")
            axes[1, i].imshow(img); axes[1, i].imshow(cam, cmap="jet", alpha=0.45)
            axes[1, i].set_title("Grad-CAM", fontsize=9); axes[1, i].axis("off")
        plt.tight_layout()
        plt.savefig(output_dir / "gradcam.png", dpi=150)
        plt.close(fig)
    else:
        print(f"⚠️  Grad-CAM غير متاح للـ backbone '{cfg.model.backbone}' "
              f"(بيرجّع embedding مباشرة بعد pooling، مش spatial feature map).")

    print(f"\n✅ كل صور المخرجات محفوظة في: {output_dir}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--experiment", default="baseline_v1")
    parser.add_argument("--configs-dir", default="configs")
    args = parser.parse_args()
    main(experiment_name=args.experiment, configs_dir=args.configs_dir)
