"""
test_rafdb.py
=============
يتحقق من:
  1) قراءة CSV وربطها بالصور صح.
  2) تحويل الـ labels من 1-based (CSV) لـ 0-based (internal).
  3) عدد العينات مطابق للمتوقع (14 train، 7 test في الـ fixture).
"""

import pytest

torch = pytest.importorskip("torch")

from emotionvia_v2.data.datasets.rafdb import RAFDBDataset  # noqa: E402


def test_train_split_loads_all_samples(rafdb_root_and_csv):
    root, train_csv, test_csv, class_names = rafdb_root_and_csv
    ds = RAFDBDataset(
        root_dir=str(root), csv_path=train_csv, class_names=class_names,
        split="train", dedup=False,
    )
    assert len(ds) == 14  # 7 classes * 2 images


def test_labels_are_zero_based(rafdb_root_and_csv):
    root, train_csv, test_csv, class_names = rafdb_root_and_csv
    ds = RAFDBDataset(
        root_dir=str(root), csv_path=train_csv, class_names=class_names,
        split="train", dedup=False,
    )
    labels = {label for _, label in ds.samples}
    assert labels == set(range(7))  # 0..6 مش 1..7


def test_test_split_loads_correctly(rafdb_root_and_csv):
    root, train_csv, test_csv, class_names = rafdb_root_and_csv
    ds = RAFDBDataset(
        root_dir=str(root), csv_path=test_csv, class_names=class_names,
        split="test", dedup=False,
    )
    assert len(ds) == 7
