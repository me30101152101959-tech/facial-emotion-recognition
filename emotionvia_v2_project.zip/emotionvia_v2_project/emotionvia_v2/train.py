"""
train.py
========
نقطة الدخول الرئيسية للتدريب — بتقرأ config (عبر emotionvia_v2/config.py)، تبني
الداتاسيتس الثلاثة مدموجة، تبني الموديل بناءً على configs/model/backbone.yaml،
تختار الـ loss المناسب بناءً على experiment.training.loss_type، وتشغّل الـ Trainer.

تشغيل:
    python -m emotionvia_v2.train --experiment baseline_v1
"""

import argparse
import random

import numpy as np
import torch
from omegaconf import DictConfig
from torch.utils.data import ConcatDataset, DataLoader, WeightedRandomSampler

from emotionvia_v2.config import load_config
from emotionvia_v2.data.datasets.emopoi import EmoPOIDataset
from emotionvia_v2.data.datasets.fer2013 import FER2013Dataset
from emotionvia_v2.data.datasets.rafdb import RAFDBDataset
from emotionvia_v2.engine.trainer import Trainer
from emotionvia_v2.losses.class_balanced_loss import compute_class_balanced_weights
from emotionvia_v2.losses.focal_loss import FocalLoss
from emotionvia_v2.models.emotion_model import EmotionViAModel

# ── mapping من فئات كل داتاسيت للفراغ الموحّد (نفس منطق النوتبوك، هنا مركزي) ──
EMOPOI_MAP = {
    "Angry": "angry", "Frustrated": "angry", "Happy": "happy", "Sad": "sad",
    "Neutral": "neutral", "Worried": "worried", "Bored": "bored",
    "Excited": "excited", "Exhausted": "exhausted",
}
FER_MAP = {
    "angry": "angry", "disgust": "angry", "fear": "fear", "happy": "happy",
    "sad": "sad", "neutral": "neutral", "surprise": "surprised",
}
RAFDB_MAP = {
    "Anger": "angry", "Disgust": "angry", "Fear": "fear", "Happy": "happy",
    "Neutral": "neutral", "Sad": "sad", "Surprise": "surprised",
}


def set_seed(seed: int):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def build_criterion(cfg: DictConfig, samples_per_class, unified_classes, device):
    training = cfg.experiment.training
    n_classes = len(unified_classes)

    if training.loss_type == "cross_entropy":
        return torch.nn.CrossEntropyLoss(label_smoothing=training.label_smoothing)

    if training.loss_type == "weighted_ce":
        counts = torch.tensor(samples_per_class, dtype=torch.float32).clamp(min=1)
        weights = (counts.sum() / (n_classes * counts)).to(device)
        return torch.nn.CrossEntropyLoss(weight=weights, label_smoothing=training.label_smoothing)

    if training.loss_type == "focal":
        counts = torch.tensor(samples_per_class, dtype=torch.float32).clamp(min=1)
        weights = (counts.sum() / (n_classes * counts)).to(device)
        return FocalLoss(alpha=weights, gamma=training.focal_gamma,
                          label_smoothing=training.label_smoothing)

    if training.loss_type == "focal_class_balanced":
        weights = compute_class_balanced_weights(
            samples_per_class, beta=training.class_balanced_beta
        ).to(device)
        return FocalLoss(alpha=weights, gamma=training.focal_gamma,
                          label_smoothing=training.label_smoothing)

    raise ValueError(f"Unknown loss_type: {training.loss_type}")


def main(experiment_name: str = "baseline_v1", configs_dir: str = "configs"):
    cfg: DictConfig = load_config(experiment_name=experiment_name, configs_dir=configs_dir)
    print(cfg)
    set_seed(cfg.experiment.seed)

    device = "cuda" if torch.cuda.is_available() else "cpu"
    unified_classes = list(cfg.experiment.unified_classes)
    cls2idx = {c: i for i, c in enumerate(unified_classes)}

    # ── الداتاسيتس الثلاثة (frame-level افتراضيًا؛ فعّل is_sequence لـ EmoPOI للـ temporal) ──
    emopoi_cfg = cfg.dataset.emopoi
    fer_cfg = cfg.dataset.fer2013
    rafdb_cfg = cfg.dataset.rafdb

    def remap_class_names(local_names, mapping):
        return [mapping[n] for n in local_names]

    print("Loading datasets …")
    # ملحوظة: كلاسات كل داتاسيت لازم تتحوّل لأندكسات الفراغ الموحّد؛ الـ Dataset
    # classes بترجّع label نسبي لقايمة class_names المحلية، فبنبني wrapper بسيط.

    def wrap_with_unified_labels(ds, local_class_names, mapping):
        """يحوّل label المحلي (0..len(local)-1) لأندكس الفراغ الموحّد."""
        remap = [cls2idx[mapping[n]] for n in local_class_names]
        ds.samples = [(p, remap[l]) for p, l in ds.samples] if hasattr(ds, "samples") else ds.samples
        return ds

    emopoi_train = EmoPOIDataset(
        root_dir=emopoi_cfg.root_dir, class_names=list(emopoi_cfg.class_names),
        split="train", image_size=tuple(emopoi_cfg.image_size), channels=emopoi_cfg.channels,
        val_frac=emopoi_cfg.val_frac, test_frac=emopoi_cfg.test_frac, seed=emopoi_cfg.seed,
        dedup=emopoi_cfg.dedup,
    )
    wrap_with_unified_labels(emopoi_train, list(emopoi_cfg.class_names), EMOPOI_MAP)
    emopoi_val = EmoPOIDataset(
        root_dir=emopoi_cfg.root_dir, class_names=list(emopoi_cfg.class_names),
        split="val", image_size=tuple(emopoi_cfg.image_size), channels=emopoi_cfg.channels,
        val_frac=emopoi_cfg.val_frac, test_frac=emopoi_cfg.test_frac, seed=emopoi_cfg.seed,
        dedup=emopoi_cfg.dedup,
    )
    wrap_with_unified_labels(emopoi_val, list(emopoi_cfg.class_names), EMOPOI_MAP)
    print(f"  EmoPOI  train={len(emopoi_train)}  val={len(emopoi_val)}")

    fer_train = FER2013Dataset(
        root_dir=fer_cfg.root_dir, class_names=list(fer_cfg.class_names), split="train",
        image_size=tuple(fer_cfg.image_size), channels=fer_cfg.channels,
        dedup=fer_cfg.dedup, cross_split_dedup=fer_cfg.cross_split_dedup,
    )
    wrap_with_unified_labels(fer_train, list(fer_cfg.class_names), FER_MAP)
    fer_val = FER2013Dataset(
        root_dir=fer_cfg.root_dir, class_names=list(fer_cfg.class_names), split="test",
        image_size=tuple(fer_cfg.image_size), channels=fer_cfg.channels,
        dedup=fer_cfg.dedup, cross_split_dedup=fer_cfg.cross_split_dedup,
    )
    wrap_with_unified_labels(fer_val, list(fer_cfg.class_names), FER_MAP)
    print(f"  FER-2013  train={len(fer_train)}  val={len(fer_val)}")

    raf_train = RAFDBDataset(
        root_dir=rafdb_cfg.root_dir, csv_path=rafdb_cfg.train_csv,
        class_names=list(rafdb_cfg.class_names), split="train",
        image_size=tuple(rafdb_cfg.image_size), channels=rafdb_cfg.channels,
        label_base=rafdb_cfg.label_base, dedup=rafdb_cfg.dedup,
    )
    wrap_with_unified_labels(raf_train, list(rafdb_cfg.class_names), RAFDB_MAP)
    raf_val = RAFDBDataset(
        root_dir=rafdb_cfg.root_dir, csv_path=rafdb_cfg.test_csv,
        class_names=list(rafdb_cfg.class_names), split="test",
        image_size=tuple(rafdb_cfg.image_size), channels=rafdb_cfg.channels,
        label_base=rafdb_cfg.label_base, dedup=rafdb_cfg.dedup,
    )
    wrap_with_unified_labels(raf_val, list(rafdb_cfg.class_names), RAFDB_MAP)
    print(f"  RAF-DB  train={len(raf_train)}  val={len(raf_val)}")

    combined_train = ConcatDataset([emopoi_train, fer_train, raf_train])
    combined_val = ConcatDataset([emopoi_val, fer_val, raf_val])
    print(f"\n  Combined  train={len(combined_train)}  val={len(combined_val)}")

    # ── توزيع الفئات + sampler ──
    all_labels = []
    for ds in [emopoi_train, fer_train, raf_train]:
        all_labels += [l for _, l in ds.samples]
    samples_per_class = np.bincount(all_labels, minlength=len(unified_classes)).tolist()

    training_cfg = cfg.experiment.training
    if training_cfg.sampler == "weighted_random":
        counts_t = torch.tensor(samples_per_class, dtype=torch.float32).clamp(min=1)
        class_w = counts_t.sum() / (len(unified_classes) * counts_t)
        sample_weights = [class_w[l].item() for l in all_labels]
        sampler = WeightedRandomSampler(sample_weights, num_samples=len(sample_weights), replacement=True)
        train_loader = DataLoader(combined_train, batch_size=training_cfg.batch_size,
                                   sampler=sampler, num_workers=training_cfg.num_workers,
                                   pin_memory=(device == "cuda"))
    else:
        train_loader = DataLoader(combined_train, batch_size=training_cfg.batch_size,
                                   shuffle=True, num_workers=training_cfg.num_workers,
                                   pin_memory=(device == "cuda"))

    val_loader = DataLoader(combined_val, batch_size=training_cfg.batch_size,
                             shuffle=False, num_workers=training_cfg.num_workers,
                             pin_memory=(device == "cuda"))

    # ── الموديل ──
    model_cfg = cfg.model
    model = EmotionViAModel(
        num_classes=len(unified_classes),
        backbone=model_cfg.backbone, pretrained=model_cfg.pretrained,
        freeze_backbone_epochs=model_cfg.freeze_backbone_epochs,
        use_attention=model_cfg.use_attention, attention_type=model_cfg.attention_type,
        cbam_reduction=model_cfg.cbam_reduction,
        use_temporal=model_cfg.use_temporal, temporal_type=model_cfg.temporal_type,
        temporal_hidden_dim=model_cfg.temporal_hidden_dim,
        temporal_num_layers=model_cfg.temporal_num_layers,
        head_hidden_dim=model_cfg.head_hidden_dim, dropout=model_cfg.dropout,
    )
    if model_cfg.freeze_backbone_epochs > 0:
        model.set_backbone_trainable(False)

    print(f"\n  Model: {model_cfg.backbone}  |  Attention: {model_cfg.attention_type}  "
          f"|  Params(trainable): {model.count_params():,}")

    # ── Loss ──
    criterion = build_criterion(cfg, samples_per_class, unified_classes, device)

    # ── Trainer ──
    trainer = Trainer(
        model=model, criterion=criterion, train_loader=train_loader, val_loader=val_loader,
        device=device, output_dir=cfg.experiment.output_dir,
        lr=training_cfg.lr, weight_decay=training_cfg.weight_decay,
        num_epochs=training_cfg.num_epochs, patience=training_cfg.patience,
        mixup_alpha=training_cfg.mixup_alpha, grad_clip_norm=training_cfg.grad_clip_norm,
        amp=training_cfg.amp,
    )
    trainer.fit()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--experiment", default="baseline_v1")
    parser.add_argument("--configs-dir", default="configs")
    args = parser.parse_args()
    main(experiment_name=args.experiment, configs_dir=args.configs_dir)
