"""
attention.py
============
تطبيق قياسي لـ CBAM (Convolutional Block Attention Module) — مُختار كـ default
في implementation_plan.md لأنه بيغطّي "what" (channel attention) و"where"
(spatial attention) معًا، وده مهم جدًا في تعابير الوجه لأن المناطق المفيدة
(عينين/حاجب/فم) محدودة مكانيًا داخل الصورة.

يُطبَّق على الـ feature map المكاني [B,C,H,W] الراجع من backbone.feature_extractor
*قبل* الـ global pooling.
"""

import torch
import torch.nn as nn


class ChannelAttention(nn.Module):
    def __init__(self, channels: int, reduction: int = 16):
        super().__init__()
        hidden = max(1, channels // reduction)
        self.mlp = nn.Sequential(
            nn.Linear(channels, hidden),
            nn.ReLU(inplace=True),
            nn.Linear(hidden, channels),
        )
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        b, c, _, _ = x.shape
        avg_out = self.mlp(self.avg_pool(x).view(b, c))
        max_out = self.mlp(self.max_pool(x).view(b, c))
        scale = torch.sigmoid(avg_out + max_out).view(b, c, 1, 1)
        return x * scale


class SpatialAttention(nn.Module):
    def __init__(self, kernel_size: int = 7):
        super().__init__()
        self.conv = nn.Conv2d(2, 1, kernel_size=kernel_size, padding=kernel_size // 2, bias=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        avg_out = x.mean(dim=1, keepdim=True)
        max_out, _ = x.max(dim=1, keepdim=True)
        pooled = torch.cat([avg_out, max_out], dim=1)
        scale = torch.sigmoid(self.conv(pooled))
        return x * scale


class CBAM(nn.Module):
    """يطبّق Channel Attention ثم Spatial Attention بالتتابع (الترتيب القياسي في الورقة الأصلية)."""

    def __init__(self, channels: int, reduction: int = 16, spatial_kernel: int = 7):
        super().__init__()
        self.channel_attention = ChannelAttention(channels, reduction)
        self.spatial_attention = SpatialAttention(spatial_kernel)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.channel_attention(x)
        x = self.spatial_attention(x)
        return x


class SqueezeExcitation(nn.Module):
    """بديل أخف من CBAM (channel-only) — متاح كخيار في config لو المطلوب سرعة أعلى."""

    def __init__(self, channels: int, reduction: int = 16):
        super().__init__()
        self.channel_attention = ChannelAttention(channels, reduction)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.channel_attention(x)
