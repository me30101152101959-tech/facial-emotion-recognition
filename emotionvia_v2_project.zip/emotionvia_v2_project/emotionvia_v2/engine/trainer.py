"""
trainer.py
==========
حلقة التدريب العامة — تشتغل مع أي EmotionViAModel (frame-level أو sequence)،
وتدعم: MixUp، Focal/Class-Balanced/Weighted-CE loss، AMP، gradient clipping،
gradual backbone unfreezing، و Early Stopping.
"""

import csv
import time
from pathlib import Path
from typing import Optional

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader

from emotionvia_v2.engine.early_stopping import EarlyStopping


def mixup_data(x: torch.Tensor, y: torch.Tensor, alpha: float = 0.2):
    if alpha <= 0:
        return x, y, y, 1.0
    lam = float(np.random.beta(alpha, alpha))
    idx = torch.randperm(x.size(0), device=x.device)
    mixed_x = lam * x + (1 - lam) * x[idx]
    return mixed_x, y, y[idx], lam


def mixup_criterion(criterion, pred, y_a, y_b, lam):
    return lam * criterion(pred, y_a) + (1 - lam) * criterion(pred, y_b)


class Trainer:
    def __init__(
        self,
        model: nn.Module,
        criterion: nn.Module,
        train_loader: DataLoader,
        val_loader: DataLoader,
        device: str,
        output_dir: str,
        lr: float = 3e-4,
        weight_decay: float = 1e-4,
        num_epochs: int = 40,
        patience: int = 7,
        mixup_alpha: float = 0.2,
        grad_clip_norm: float = 1.0,
        amp: bool = True,
    ):
        self.model = model.to(device)
        self.criterion = criterion
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.device = device
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

        self.num_epochs = num_epochs
        self.mixup_alpha = mixup_alpha
        self.grad_clip_norm = grad_clip_norm
        self.amp = amp and device == "cuda"

        self.optimizer = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=weight_decay)
        self.scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
            self.optimizer, T_max=num_epochs, eta_min=1e-6
        )
        self.scaler = torch.amp.GradScaler("cuda", enabled=self.amp)
        self.early_stopping = EarlyStopping(patience=patience, mode="max")

        self.best_ckpt_path = self.output_dir / "best_model.pt"
        self.log_path = self.output_dir / "metrics.csv"
        with open(self.log_path, "w", newline="") as f:
            csv.writer(f).writerow(["epoch", "train_loss", "train_acc", "val_loss", "val_acc", "lr"])

    def _run_epoch(self, loader: DataLoader, train: bool) -> tuple:
        self.model.train(train)
        total_loss = total_acc = 0.0
        with torch.set_grad_enabled(train):
            for x, y in loader:
                x, y = x.to(self.device), y.to(self.device)

                if train and self.mixup_alpha > 0:
                    x, y_a, y_b, lam = mixup_data(x, y, self.mixup_alpha)
                    with torch.amp.autocast("cuda", enabled=self.amp):
                        out = self.model(x)
                        loss = mixup_criterion(self.criterion, out, y_a, y_b, lam)
                else:
                    with torch.amp.autocast("cuda", enabled=self.amp):
                        out = self.model(x)
                        loss = self.criterion(out, y)

                if train:
                    self.optimizer.zero_grad(set_to_none=True)
                    self.scaler.scale(loss).backward()
                    self.scaler.unscale_(self.optimizer)
                    nn.utils.clip_grad_norm_(self.model.parameters(), self.grad_clip_norm)
                    self.scaler.step(self.optimizer)
                    self.scaler.update()

                total_loss += loss.item()
                total_acc += (out.argmax(1) == y).float().mean().item()

        n = max(1, len(loader))
        return total_loss / n, total_acc / n

    def fit(self):
        print(f"Training for up to {self.num_epochs} epochs "
              f"(early stopping patience={self.early_stopping.patience}) …\n")

        for epoch in range(1, self.num_epochs + 1):
            unfroze = False
            if hasattr(self.model, "maybe_unfreeze"):
                unfroze = self.model.maybe_unfreeze(epoch)
                if unfroze:
                    print(f"  🔓 fine-tuning: backbone unfrozen at epoch {epoch}")

            t0 = time.time()
            tr_loss, tr_acc = self._run_epoch(self.train_loader, train=True)
            va_loss, va_acc = self._run_epoch(self.val_loader, train=False)
            self.scheduler.step()
            elapsed = time.time() - t0
            lr_now = self.optimizer.param_groups[0]["lr"]

            print(f"Epoch {epoch:3d}/{self.num_epochs}  "
                  f"| train loss={tr_loss:.4f} acc={tr_acc:.3f}  "
                  f"| val loss={va_loss:.4f} acc={va_acc:.3f}  "
                  f"| lr={lr_now:.1e}  | {elapsed:.0f}s")

            with open(self.log_path, "a", newline="") as f:
                csv.writer(f).writerow([epoch, f"{tr_loss:.5f}", f"{tr_acc:.5f}",
                                         f"{va_loss:.5f}", f"{va_acc:.5f}", f"{lr_now:.2e}"])

            is_best = self.early_stopping.step(va_acc)
            if is_best:
                torch.save({
                    "epoch": epoch, "model_state": self.model.state_dict(), "val_acc": va_acc,
                }, self.best_ckpt_path)
                print(f"  ✓ saved best (val_acc={va_acc:.3f})")

            if self.early_stopping.should_stop:
                print(f"\n⏹ Early stopping: مفيش تحسّن من {self.early_stopping.patience} epochs.")
                break

        print(f"\nDone. Best val_acc = {self.early_stopping.best_value:.3f}")
        print(f"Checkpoint : {self.best_ckpt_path}")
        print(f"Log        : {self.log_path}\n")
        return self.best_ckpt_path, self.log_path
