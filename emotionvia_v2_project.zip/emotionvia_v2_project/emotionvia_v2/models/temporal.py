"""
temporal.py
===========
موديولات زمنية اختيارية — تُستخدم فقط لو الداتاسيت شغّال بوضع sequence
(EmoPOI مع is_sequence=true) لالتقاط ديناميكية تعابير الوجه عبر الفريمات.

المُدخل الموحّد لكل الموديولات: [B, T, D] (D = feat_dim من الـ backbone بعد الـ pooling
لكل فريم على حدة)، والمُخرج: [B, D_out] (متجه واحد مُلخّص للـ sequence كله).

الاختيار الافتراضي (implementation_plan.md): BiLSTM أو TCN — الاتنين مناسبين
للـ sequences القصيرة زي EmoPOI؛ Transformer Encoder متاح كخيار لسلاسل أطول.
"""

import torch
import torch.nn as nn


class BiLSTMTemporal(nn.Module):
    def __init__(self, input_dim: int, hidden_dim: int = 256, num_layers: int = 1):
        super().__init__()
        self.lstm = nn.LSTM(
            input_size=input_dim, hidden_size=hidden_dim, num_layers=num_layers,
            batch_first=True, bidirectional=True,
        )
        self.output_dim = hidden_dim * 2

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: [B, T, D]
        out, (h_n, _) = self.lstm(x)
        # دمج آخر hidden state من الاتجاهين (forward + backward)
        forward_last = h_n[-2]
        backward_last = h_n[-1]
        return torch.cat([forward_last, backward_last], dim=-1)  # [B, 2*hidden_dim]


class _TemporalBlock(nn.Module):
    """Dilated causal 1D conv block (TCN building block)."""

    def __init__(self, in_ch: int, out_ch: int, kernel_size: int, dilation: int):
        super().__init__()
        padding = (kernel_size - 1) * dilation
        self.conv = nn.Conv1d(in_ch, out_ch, kernel_size, padding=padding, dilation=dilation)
        self.chomp = padding  # نقصّ الـ padding الزايد من الآخر عشان نحافظ على السببية (causal)
        self.relu = nn.ReLU()
        self.norm = nn.BatchNorm1d(out_ch)
        self.downsample = nn.Conv1d(in_ch, out_ch, 1) if in_ch != out_ch else None

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        out = self.conv(x)
        if self.chomp > 0:
            out = out[:, :, :-self.chomp]
        out = self.relu(self.norm(out))
        res = x if self.downsample is None else self.downsample(x)
        return self.relu(out + res)


class TCNTemporal(nn.Module):
    def __init__(self, input_dim: int, hidden_dim: int = 256, num_layers: int = 3, kernel_size: int = 3):
        super().__init__()
        layers = []
        in_ch = input_dim
        for i in range(num_layers):
            dilation = 2 ** i
            layers.append(_TemporalBlock(in_ch, hidden_dim, kernel_size, dilation))
            in_ch = hidden_dim
        self.net = nn.Sequential(*layers)
        self.output_dim = hidden_dim

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: [B, T, D] -> Conv1d محتاج [B, D, T]
        x = x.transpose(1, 2)
        out = self.net(x)               # [B, hidden_dim, T]
        return out.mean(dim=-1)          # global average pooling عبر الزمن -> [B, hidden_dim]


class TransformerTemporal(nn.Module):
    """خيار لسلاسل أطول من فريمات EmoPOI القصيرة (غير مفعّل افتراضيًا)."""

    def __init__(self, input_dim: int, hidden_dim: int = 256, num_heads: int = 4, num_layers: int = 2):
        super().__init__()
        self.proj = nn.Linear(input_dim, hidden_dim)
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=hidden_dim, nhead=num_heads, batch_first=True
        )
        self.encoder = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)
        self.output_dim = hidden_dim

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.proj(x)
        out = self.encoder(x)
        return out.mean(dim=1)


def build_temporal_module(kind: str, input_dim: int, hidden_dim: int = 256, num_layers: int = 1) -> nn.Module:
    kind = kind.lower()
    if kind == "bilstm":
        return BiLSTMTemporal(input_dim, hidden_dim, num_layers)
    if kind == "tcn":
        return TCNTemporal(input_dim, hidden_dim, max(1, num_layers))
    if kind == "transformer":
        return TransformerTemporal(input_dim, hidden_dim, num_layers=max(1, num_layers))
    raise ValueError(f"Unknown temporal module: {kind}")
